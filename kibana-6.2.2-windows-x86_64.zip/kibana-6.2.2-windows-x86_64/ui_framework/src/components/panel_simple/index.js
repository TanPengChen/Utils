'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _panel_simple = require('./panel_simple');

Object.defineProperty(exports, 'KuiPanelSimple', {
  enumerable: true,
  get: function get() {
    return _panel_simple.KuiPanelSimple;
  }
});
Object.defineProperty(exports, 'SIZES', {
  enumerable: true,
  get: function get() {
    return _panel_simple.SIZES;
  }
});
