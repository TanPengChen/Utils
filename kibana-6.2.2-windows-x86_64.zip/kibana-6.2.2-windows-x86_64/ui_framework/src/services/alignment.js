'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const LEFT_ALIGNMENT = exports.LEFT_ALIGNMENT = 'left';
const RIGHT_ALIGNMENT = exports.RIGHT_ALIGNMENT = 'right';
